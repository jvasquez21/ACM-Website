1. Fix main image to be full screen then scroll down
2. Adjust NavBar to scale
3. set content divs - add bootstrap cols
4. set forms to email info to acm.utsa@gmail.com
5. Back to top button
Content Sections: (Index)

about

mission

events - able to add new events to the top of this section

Pages:

Calendar

Contact - forms (using page)



Notes:
Nav2 is for home page to link to parts further down the page.
Nav 1 is for other pages.
